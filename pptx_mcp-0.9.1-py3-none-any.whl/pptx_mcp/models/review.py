"""Pydantic models for presentation review and design critique."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    SUGGESTION = "suggestion"


class ReviewCategory(str, Enum):
    LAYOUT = "layout"
    TYPOGRAPHY = "typography"
    COLOR = "color"
    CONTENT = "content"
    CONSISTENCY = "consistency"
    WHITESPACE = "whitespace"
    NARRATIVE = "narrative"
    BRAND = "brand"
    ACCESSIBILITY = "accessibility"


class ReviewIssue(BaseModel):
    """A single design or content issue found during review."""

    severity: Severity
    category: ReviewCategory
    message: str
    slide_index: Optional[int] = Field(
        default=None, description="0-based slide index, None if deck-level"
    )
    element_description: Optional[str] = Field(
        default=None, description="Description of the affected element"
    )
    suggestion: Optional[str] = Field(
        default=None, description="Actionable fix suggestion"
    )


class SlideReview(BaseModel):
    """Review results for a single slide."""

    slide_index: int
    slide_type: Optional[str] = None
    title: Optional[str] = None
    word_count: int = 0
    element_count: int = 0
    issues: list[ReviewIssue] = Field(default_factory=list)
    score: float = Field(
        default=10.0,
        description="Slide quality score from 0.0 to 10.0",
        ge=0.0,
        le=10.0,
    )


class ReviewResult(BaseModel):
    """Complete review result for a presentation."""

    overall_score: float = Field(
        description="Overall deck quality score from 0.0 to 10.0",
        ge=0.0,
        le=10.0,
    )
    total_slides: int
    total_issues: int
    issues: list[ReviewIssue] = Field(default_factory=list)
    slide_reviews: list[SlideReview] = Field(default_factory=list)
    summary: str = Field(description="Human-readable review summary")
    strengths: list[str] = Field(default_factory=list)
    improvements: list[str] = Field(default_factory=list)
