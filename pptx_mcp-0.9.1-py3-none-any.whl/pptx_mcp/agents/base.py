"""Base agent interface for all internal agents."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Generic, TypeVar

from pydantic import BaseModel

from pptx_mcp.utils.logging import get_logger

InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT", bound=BaseModel)


class BaseAgent(ABC, Generic[InputT, OutputT]):
    """Abstract base class for all PPTX MCP agents.

    Agents are deterministic transformation units. They accept structured input
    and produce structured output. The LLM orchestrator sits above them and
    makes creative decisions; agents apply rules and heuristics.
    """

    def __init__(self) -> None:
        self.logger = get_logger(f"agents.{self.name}")

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable agent name."""

    @property
    @abstractmethod
    def description(self) -> str:
        """One-line description of the agent's purpose."""

    @abstractmethod
    def run(self, input_data: InputT) -> OutputT:
        """Execute the agent's logic.

        Args:
            input_data: Validated input model.

        Returns:
            Output model with the agent's results.
        """

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}: {self.name}>"
