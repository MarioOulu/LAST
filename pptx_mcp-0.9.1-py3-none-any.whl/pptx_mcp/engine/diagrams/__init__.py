"""Diagram renderers for v0.6.0 slide types."""

from __future__ import annotations

from pptx_mcp.engine.diagrams.org_chart import render_org_chart_slide
from pptx_mcp.engine.diagrams.matrix import render_matrix_slide
from pptx_mcp.engine.diagrams.pyramid import render_pyramid_slide
from pptx_mcp.engine.diagrams.venn import render_venn_slide
from pptx_mcp.engine.diagrams.waterfall import render_waterfall_slide
from pptx_mcp.engine.diagrams.hub_spoke import render_hub_spoke_slide
from pptx_mcp.engine.diagrams.cycle import render_cycle_slide
from pptx_mcp.engine.diagrams.gantt import render_gantt_slide

__all__ = [
    "render_org_chart_slide",
    "render_matrix_slide",
    "render_pyramid_slide",
    "render_venn_slide",
    "render_waterfall_slide",
    "render_hub_spoke_slide",
    "render_cycle_slide",
    "render_gantt_slide",
]
