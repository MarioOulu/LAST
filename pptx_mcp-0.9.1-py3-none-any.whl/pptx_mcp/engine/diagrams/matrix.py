"""2x2 matrix diagram renderer."""

from __future__ import annotations

from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.slide import Slide
from pptx.util import Inches, Pt

from pptx_mcp.engine.composition import LayoutGrid, Margin
from pptx_mcp.engine.diagrams._common import brand_color_at
from pptx_mcp.engine.layouts import _add_slide_title, _apply_text_frame_padding
from pptx_mcp.engine.shapes import parse_hex_color, set_corner_radius
from pptx_mcp.models.brand import BrandConfig
from pptx_mcp.models.diagrams import MatrixQuadrant
from pptx_mcp.models.slides import SlideDefinition


def render_matrix_slide(
    slide: Slide,
    definition: SlideDefinition,
    brand: BrandConfig,
    slide_width: float,
) -> None:
    """Render a 2x2 quadrant matrix diagram."""
    _add_slide_title(slide, definition.title, brand, slide_width)

    matrix = definition.matrix
    if matrix is None:
        return

    sp = brand.spacing
    # Reserve space for axis labels
    axis_margin = 0.5
    grid = LayoutGrid(
        slide_width=slide_width,
        slide_height=7.5,
        margin=Margin(
            left=sp.margin_left + axis_margin,
            right=sp.margin_right,
            top=sp.content_top,
            bottom=sp.margin_bottom + axis_margin,
        ),
    )

    quadrants = grid.grid(2, 2, h_gap=0.2, v_gap=0.2)

    quadrant_data: list[tuple[MatrixQuadrant, int, int]] = [
        (matrix.top_left, 0, 0),
        (matrix.top_right, 0, 1),
        (matrix.bottom_left, 1, 0),
        (matrix.bottom_right, 1, 1),
    ]

    for idx, (quad, row, col) in enumerate(quadrant_data):
        cell = quadrants[row][col]
        fill_hex = quad.color or brand_color_at(brand, idx)

        header_h = 0.4
        # Header bar
        header = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE,
            Inches(cell.left), Inches(cell.top),
            Inches(cell.width), Inches(header_h),
        )
        header.fill.solid()
        header.fill.fore_color.rgb = parse_hex_color(fill_hex)
        header.line.fill.background()
        set_corner_radius(header, brand.shape_style.card_corner_radius)

        tf = header.text_frame
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.text = quad.label
        p.alignment = PP_ALIGN.CENTER
        run = p.runs[0]
        run.font.name = brand.fonts.heading_font
        run.font.size = Pt(13)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

        # Body area with items
        if quad.items:
            body_box = slide.shapes.add_textbox(
                Inches(cell.left), Inches(cell.top + header_h + 0.08),
                Inches(cell.width), Inches(cell.height - header_h - 0.08),
            )
            btf = body_box.text_frame
            btf.word_wrap = True
            _apply_text_frame_padding(btf, brand)
            for i, item in enumerate(quad.items[:6]):
                p = btf.paragraphs[0] if i == 0 else btf.add_paragraph()
                p.text = f"\u2022 {item}"
                p.space_after = Pt(3)
                run = p.runs[0]
                run.font.name = brand.fonts.body_font
                run.font.size = Pt(11)
                run.font.color.rgb = parse_hex_color(brand.colors.text_primary)

    # Axis labels
    if matrix.x_axis_label:
        content_left = sp.margin_left + axis_margin
        content_w = slide_width - content_left - sp.margin_right
        x_label = slide.shapes.add_textbox(
            Inches(content_left), Inches(7.5 - sp.margin_bottom - 0.35),
            Inches(content_w), Inches(0.35),
        )
        xtf = x_label.text_frame
        p = xtf.paragraphs[0]
        p.text = matrix.x_axis_label
        p.alignment = PP_ALIGN.CENTER
        run = p.runs[0]
        run.font.name = brand.fonts.body_font
        run.font.size = Pt(11)
        run.font.bold = True
        run.font.color.rgb = parse_hex_color(brand.colors.text_secondary)

    if matrix.y_axis_label:
        y_label = slide.shapes.add_textbox(
            Inches(sp.margin_left), Inches(sp.content_top),
            Inches(axis_margin - 0.05), Inches(7.5 - sp.content_top - sp.margin_bottom - axis_margin),
        )
        ytf = y_label.text_frame
        ytf.word_wrap = True
        p = ytf.paragraphs[0]
        p.text = matrix.y_axis_label
        p.alignment = PP_ALIGN.CENTER
        run = p.runs[0]
        run.font.name = brand.fonts.body_font
        run.font.size = Pt(11)
        run.font.bold = True
        run.font.color.rgb = parse_hex_color(brand.colors.text_secondary)
        # Rotate 270 degrees for vertical text
        y_label.rotation = 270.0
