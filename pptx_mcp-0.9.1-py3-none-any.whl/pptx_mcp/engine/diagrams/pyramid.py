"""Pyramid diagram renderer — layers that widen from top to bottom."""

from __future__ import annotations

from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.slide import Slide
from pptx.util import Inches, Pt

from pptx_mcp.engine.diagrams._common import brand_color_at
from pptx_mcp.engine.layouts import _add_slide_title
from pptx_mcp.engine.shapes import parse_hex_color, set_corner_radius
from pptx_mcp.models.brand import BrandConfig
from pptx_mcp.models.slides import SlideDefinition


def render_pyramid_slide(
    slide: Slide,
    definition: SlideDefinition,
    brand: BrandConfig,
    slide_width: float,
) -> None:
    """Render a pyramid diagram with layers widening from top to bottom."""
    _add_slide_title(slide, definition.title, brand, slide_width)

    layers = definition.pyramid_layers
    if not layers:
        return

    n = min(len(layers), 8)
    sp = brand.spacing
    content_w = slide_width - sp.margin_left - sp.margin_right
    content_top = sp.content_top + 0.2
    content_h = 7.5 - content_top - sp.margin_bottom

    layer_gap = 0.08
    layer_h = (content_h - layer_gap * (n - 1)) / n

    # Width range: narrowest at top, widest at bottom
    min_width = content_w * 0.2
    max_width = content_w * 0.7

    for i, layer in enumerate(layers[:n]):
        # Width increases linearly top→bottom
        ratio = i / max(n - 1, 1)
        w = min_width + (max_width - min_width) * ratio
        left = sp.margin_left + (content_w * 0.7 - w) / 2  # center within left portion
        top = content_top + i * (layer_h + layer_gap)

        fill_hex = layer.color or brand_color_at(brand, i)

        rect = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE,
            Inches(left), Inches(top),
            Inches(w), Inches(layer_h),
        )
        rect.fill.solid()
        rect.fill.fore_color.rgb = parse_hex_color(fill_hex)
        rect.line.fill.background()
        set_corner_radius(rect, brand.shape_style.card_corner_radius)

        tf = rect.text_frame
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = layer.label
        p.alignment = PP_ALIGN.CENTER
        run = p.runs[0]
        run.font.name = brand.fonts.heading_font
        run.font.size = Pt(13)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

        # Description text to the right
        if layer.description:
            desc_left = sp.margin_left + content_w * 0.7 + 0.3
            desc_w = content_w - content_w * 0.7 - 0.3
            if desc_w > 0.5:
                desc_box = slide.shapes.add_textbox(
                    Inches(desc_left), Inches(top),
                    Inches(desc_w), Inches(layer_h),
                )
                dtf = desc_box.text_frame
                dtf.word_wrap = True
                dtf.vertical_anchor = MSO_ANCHOR.MIDDLE
                p = dtf.paragraphs[0]
                p.text = layer.description
                run = p.runs[0]
                run.font.name = brand.fonts.body_font
                run.font.size = Pt(11)
                run.font.color.rgb = parse_hex_color(brand.colors.text_secondary)
