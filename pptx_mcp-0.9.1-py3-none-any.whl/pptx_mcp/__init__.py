"""PPTX MCP - Model Context Protocol server for PowerPoint generation."""

__version__ = "0.9.1"
